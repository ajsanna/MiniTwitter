/*
 * Alexander J Sanna
 * CS3560 OOP Assignment 2
 * Professor Y. Sun
 * Due: June 25th, 2023 
 * 
 * Description: 
 * 	This is the interface to depict which classes are widgets. 
	this is a composite design feature and is utilzied here for pure code organization. 
 */

public interface Widget 
{
	//no required methods. 
}
